package com.hengki.github

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Users (
    val name: String,
    val description: String,
    val photo: Int
) : Parcelable
